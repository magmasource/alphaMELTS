def test_import():
    from alphamelts.py.main import main  # type: ignore
    main(1)
